export const headingContainer = {
  textAlign: 'center',
  paddingTop: 30,
}

export const paddedItem = { width: 1950, maxWidth: '95%', margin: 'auto' }
