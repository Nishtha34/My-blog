export const NAME = 'DevX'
export const NAME_AND_DOMAIN = 'DevX.sh'
export const BASE_URL = 'https://devx.sh'
export const DEPLOYMENTS_URL = 'https://api.github.com/repos/FelixMohr/nextjs-material-ui-blog/deployments'
